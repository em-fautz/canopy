<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to goodwish_edge_style_dynamic hook
 */

//if (!function_exists('goodwish_edge_counter_style')) {
//
//	function goodwish_edge_counter_style()
//	{
//
//		if (goodwish_edge_options()->getOptionValue('option_value') !== '') {
//			echo goodwish_edge_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => goodwish_edge_filter_px(goodwish_edge_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('goodwish_edge_style_dynamic', 'goodwish_edge_counter_style');
//
//}

?>