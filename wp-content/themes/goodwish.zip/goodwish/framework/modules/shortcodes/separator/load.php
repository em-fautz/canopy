<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/separator/separator.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/separator/custom-styles/separator.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/separator/separator-functions.php';

