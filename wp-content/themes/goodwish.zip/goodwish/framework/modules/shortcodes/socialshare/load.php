<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/socialshare/social-share-functions.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/socialshare/social-share.php';