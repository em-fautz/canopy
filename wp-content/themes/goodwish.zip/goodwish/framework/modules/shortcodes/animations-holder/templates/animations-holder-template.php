<div <?php goodwish_edge_class_attribute($class); ?> <?php echo goodwish_edge_get_inline_attrs($data); ?>>
	<div <?php goodwish_edge_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>