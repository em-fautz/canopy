<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/item-showcase/item-showcase.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/item-showcase/item-showcase-list-item.php';
