<?php
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/elements-holder/elements-holder.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/elements-holder/elements-holder-item.php';
