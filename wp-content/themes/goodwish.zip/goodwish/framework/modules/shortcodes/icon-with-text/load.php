<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/icon-with-text/icon-with-text.php';