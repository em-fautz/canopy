<div class="edgtf-event-content">
    <?php the_content(); ?>
</div>