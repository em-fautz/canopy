<?php 

if (goodwish_edge_is_give_installed()){
	include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/give/give-config.php';
	include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/give/give-functions.php';
	include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/give/give-template-hooks.php';
}