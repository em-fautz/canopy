<div class="edgtf-blog-like">
	<?php if( function_exists('goodwish_edge_get_like') ) goodwish_edge_get_like(); ?>
</div>