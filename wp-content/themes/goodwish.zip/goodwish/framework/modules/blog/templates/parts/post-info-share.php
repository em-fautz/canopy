<div class ="edgtf-blog-share">
	<?php
		if(goodwish_edge_core_installed()) {
			echo goodwish_edge_get_social_share_html();
		}
	?>
</div>