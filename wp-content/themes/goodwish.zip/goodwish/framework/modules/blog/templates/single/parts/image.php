<?php if ( has_post_thumbnail() ) { ?>
	<div class="edgtf-post-image">
			<?php the_post_thumbnail('full'); ?>
	</div>
<?php } ?>